package com.student.repository;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.entity.Student;

@Repository
public class StudentDao {

	@Autowired
	SessionFactory factory;
	public boolean saveRecord(Student student) {
		Session session = factory.openSession();
		Transaction tx =session.beginTransaction();
		
		session.save(student);
		tx.commit();
		return true;
	}
	
	public Student getRecord(int id) {
		Session session = factory.openSession();
		Student student=session.get(Student.class, id);
		if(student == null)
			return student;
		else
			return student;
	}
	
	public String deleteRecord(int id) {
		Session session = factory.openSession();
		Student student=session.get(Student.class, id);
		if(student != null) {
			session.delete(id);
			return "Successfully deleted";
		}	
		else
			return "Record Not Present";
	}
	
	public String updateRecord(Student student ,int id) {
		Session session = factory.openSession();
		Transaction tx =session.beginTransaction();
		Student student1=session.get(Student.class, id);
		
		session.clear();
		if(student1 != null) {
		    session.update(student);
		    tx.commit();
		    return "Record Updated Successfully";
		}
		else
			return "Record Not Present";
	}
	
	
	
}
