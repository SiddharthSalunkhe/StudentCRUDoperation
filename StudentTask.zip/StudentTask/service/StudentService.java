package com.student.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.Student;
import com.student.repository.StudentDao;

@Service
public class StudentService {
    @Autowired
    StudentDao studDao;
    
    public boolean save(Student student) {
    	return studDao.saveRecord(student);
    }
    
    public Student getRecord(int id) {
    	return studDao.getRecord(id);
    }
    
    public String deleteRecord(int id) {
    	return studDao.deleteRecord(id);
    }
    
    public String updateRecord(Student student,int id) {
    	return studDao.updateRecord(student,id);
    }
}
